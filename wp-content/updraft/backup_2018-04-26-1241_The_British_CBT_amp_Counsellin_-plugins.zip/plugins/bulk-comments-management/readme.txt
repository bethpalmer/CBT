=== Bulk Comments Management ===
Contributors: yakuphoca
Donate link: http://www.yakuphoca.com/
Tags: comments, spam, unapproved, delete tracakbacks, delete comments, disable comments, enable comments, bulk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Requires at least: 3.3
Tested up to: 3.5.2
Stable tag: 1.0

This plugin allows administrators to globally delete comments (spam, trash, unapproved comments), enable/disable comments on all posts.

== Description ==

This plugin allows administrators to globally delete comments (spam, trash, unapproved comments), enable/disable comments on all posts.


== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. The plugin settings page can be accessed via the 'Tools' menu in the administration area.

== Frequently Asked Questions ==

There is no Question.

== Screenshots ==

1. Bulk Comments Management Plugin Settings Page

== Changelog ==

= 1.0 =

* Initial Version

== Upgrade Notice ==

There is no Upgrade Notice