<p><!-- SPACING --></p>
<?php cau_fetch_log( 'all', 'table' ); ?>