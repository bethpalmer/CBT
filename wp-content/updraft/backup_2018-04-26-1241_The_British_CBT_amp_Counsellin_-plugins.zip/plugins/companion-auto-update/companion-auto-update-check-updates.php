<?php

// Deprecated file as of version 3.0. Will be removed in a future update.
require_once( 'cau_emails.php' ); // Fallback

?>