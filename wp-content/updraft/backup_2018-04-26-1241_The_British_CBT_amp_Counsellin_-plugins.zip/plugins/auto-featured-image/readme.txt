=== Plugin Name ===
Contributors: ka-yue
Donate link: http://ka-yue.com/
Tags: Featured image, thumbnail
Requires at least: 3.0
Tested up to: 3.0
Stable tag: 1.2

Automatically generate featured image for new/old posts if Post Thumbnail is not set manually. It also support external image and Youtube, Vimeo, DailyMotion videos. Forked from Aditya Mooley.

== Description ==

Automatically generate featured image for new/old posts if Post Thumbnail is not set manually. 

It also support external image and Youtube, Vimeo, DailyMotion videos. Forked from Aditya Mooley.