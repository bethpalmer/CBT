menu-limit-detector
===================

A simple WordPress plugin that attempts to detect server configurations that may limit the number of menu items a user can save.
