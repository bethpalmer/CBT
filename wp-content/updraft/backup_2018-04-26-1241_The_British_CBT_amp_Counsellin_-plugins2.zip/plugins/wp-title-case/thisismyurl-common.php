<?php

/**
 *
 * thisismyurl.com common WordPress plugin files
 *
 * This file contains all the logic required for the plugin
 *
 * @package 	thisismyurl.com common WordPress plugin
 * @copyright	Copyright (c) 2014, Chrsitopher Ross
 * @license		http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License, v2 (or newer)
 *
 * @since 		thisismyurl.com common WordPress plugin 15.01
 * @version		15.01
 *
 */


/* if the plugin is called directly, die */
if ( ! defined( 'WPINC' ) )
	die;




/**
 * Creates the class required for thisismyurl.com common WordPress plugin files
 *
 * @author	Christopher Ross <info@thisismyurl.com>
 * @version    Release: @15.01@
 * @since	 Class available since Release 14.11
 *
 */
class thisismyurl_Common_WPTC {


	/**
	  * Standard Constructor
	  *
	  * @access public
	  * @static
	  * @uses http://codex.wordpress.org/Function_Reference/add_action
	  * @since Method available since Release 14.11
	  *
	  */
    public function __construct() {

 		/* loaded for both */
 		add_action( 'plugins_loaded', 			array( $this, 'load_textdomain' ) );
		add_action( 'activate_plugin_name', 	array( $this, 'activate_plugin_name' ) );
		add_action( 'deactivate_plugin_name', 	array( $this, 'deactivate_plugin_name' ) );


		/* front end only */
		add_action( 'wp_enqueue_scripts', 		array( $this, 'enqueue_style' ) );


		/* admin only */
		add_action( 'admin_enqueue_scripts', 	array( $this, 'admin_enqueue_scripts' ) );
		add_action( 'admin_menu', 				array( $this, 'admin_menu' ) );
		add_filter( 'plugin_action_links_' . THISISMYURL_WPTC_FILENAME, array( $this, 'add_action_link' ), 10, 2 );
		add_action( 'admin_init', 				array( $this, 'admin_init' ) );

		register_uninstall_hook( 'uninstall.php', false );


    }



	/**
	  * load_textdomain
	  *
	  * @access public
	  * @static
	  * @uses http://codex.wordpress.org/Function_Reference/load_plugin_textdomain
	  * @since Method available since Release 14.11
	  *
	  */
 	function load_textdomain() {

		/* loads the plugin text domain and language files */
		load_plugin_textdomain( THISISMYURL_WPTC_TEXTDOMAIN,
								false,
								THISISMYURL_WPTC_FILEPATH . '/langs'
		);

	}



	/**
	  * activate_plugin_name
	  *
	  * @access public
	  * @static
	  * @since Method available since Release 15.01
	  *
	  */
 	function activate_plugin_name() {

	}



	/**
	  * deactivate_plugin_name
	  *
	  * @access public
	  * @static
	  * @since Method available since Release 15.01
	  *
	  */
 	function deactivate_plugin_name() {

	}



	/**
	  * enqueue_style
	  *
	  * @access public
	  * @static
	  * @uses http://codex.wordpress.org/Function_Reference/wp_enqueue_style
	  * @since Method available since Release 14.11
	  *
	  */
    public function enqueue_style() {
		
		/* enqueue the style if it's found */
		if ( file_exists( dirname( __FILE__ ) . '/css/' . THISISMYURL_WPTC_NAMESPACE . '.css' ) ) {

			wp_enqueue_style( 	THISISMYURL_WPTC_NAMESPACE,
								THISISMYURL_WPTC_FILEPATHURL . 'css/' . THISISMYURL_WPTC_NAMESPACE . '.css',
								false,
								THISISMYURL_WPTC_VERSION
							);
		
		}

		/* enqueue the script if it's found */
		if ( file_exists( THISISMYURL_WPTC_FILEPATH . '/js/' . THISISMYURL_WPTC_NAMESPACE . '.js' ) ) {

			wp_enqueue_style( 	THISISMYURL_WPTC_NAMESPACE,
								THISISMYURL_WPTC_FILEPATHURL . 'js/' . THISISMYURL_WPTC_NAMESPACE . '.js',
								false,
								THISISMYURL_WPTC_VERSION
							);
		
		}


	}



	/**
	  * admin_enqueue_scripts
	  *
	  * @access public
	  * @static
	  * @uses http://codex.wordpress.org/Function_Reference/wp_enqueue_style
	  * @since Method available since Release 14.12
	  *
	  */
	function admin_enqueue_scripts() {


		if ( isset( $_GET['page'] ) ) {

			/* only load this function on the correct admin pages */
			if ( THISISMYURL_WPTC_TEXTDOMAIN . '_settings_page' != $_GET['page'] )
			   return;

			wp_register_style(  'thisismyurl-common',
								THISISMYURL_WPTC_FILEPATHURL . 'css/thisismyurl-common.css',
								false,
								THISISMYURL_WPTC_VERSION
							);
		
		    wp_enqueue_style( 'thisismyurl-common' );

			/* enqueue a special admin style if it's found */
			if ( file_exists( THISISMYURL_WPTC_FILEPATH . 'css/' . THISISMYURL_WPTC_NAMESPACE . '-admin.css' ) ) {

				wp_enqueue_style( 	THISISMYURL_WPTC_NAMESPACE,
									THISISMYURL_WPTC_FILEPATHURL . 'css/' . THISISMYURL_WPTC_NAMESPACE . '-admin.css',
									false,
									THISISMYURL_WPTC_VERSION
								);
			
			}

			/* enqueue a special admin script if it's found */
			if ( file_exists( THISISMYURL_WPTC_FILEPATH . 'js/' . THISISMYURL_WPTC_NAMESPACE . '-admin.js' ) ) {

				wp_enqueue_style( 	THISISMYURL_WPTC_NAMESPACE,
									THISISMYURL_WPTC_FILEPATHURL . 'js/' . THISISMYURL_WPTC_NAMESPACE . '-admin.js',
									false,
									THISISMYURL_WPTC_VERSION
								);
			
			}


		}

	}



	/**
	  * admin_menu
	  *
	  * @access public
	  * @static
	  * @uses http://codex.wordpress.org/Function_Reference/add_options_page
	  * @since Method available since Release 14.12
	  *
	  * @todo change the parent menu if there is no settings
	  *
	  */
	function admin_menu() {

		/* add the page, set capacities etc */
		add_options_page( 	THISISMYURL_WPTC_SHORTNAME,
							THISISMYURL_WPTC_SHORTNAME,
							'manage_options',
							THISISMYURL_WPTC_TEXTDOMAIN . '_settings_page',
							array( $this, 'settings_page' )
						);

		/* remove the menu item from settings */
		if ( ! file_exists( dirname( __FILE__ ) . '/' . THISISMYURL_WPTC_NAMESPACE . '-settings.php' ) ) 
			remove_submenu_page( 'options-general.php', THISISMYURL_WPTC_TEXTDOMAIN . '_settings_page' );
	
	}



	/**
	  * plugin_action_links
	  *
	  * @access public
	  * @static
	  * @since Method available since Release 14.12
	  *
	  */
	function add_action_link( $links, $file ) {

		static $this_plugin;

		if( ! $this_plugin )
			$this_plugin = plugin_basename( __FILE__ );

		if( dirname( $file ) == dirname( $this_plugin ) ) {
			$links[] = sprintf( '<a href="options-general.php?page=%s">%s</a>',
								THISISMYURL_WPTC_TEXTDOMAIN . '_settings_page',
								__( 'Settings', THISISMYURL_WPTC_TEXTDOMAIN )
							);
		}

		return $links;

	}



	/**
	  * plugin_action_links
	  *
	  * @access public
	  * @static
	  * @since Method available since Release 14.12
	  *
	  */
	function settings_page() {


	?>
	<div id="thisismyurl-settings" class="wrap">
		<div class="thisismyurl-icon32"><br /></div>
		<h2><?php echo THISISMYURL_WPTC_NAME; ?></h2>

        <form method="POST" action="options.php">
		<?php 
        settings_fields( 'thisismyurl_wp_title_case' );	
        do_settings_sections( 'thisismyurl_wp_title_case' );
        submit_button();
        ?>
        </form>


	</div>

    <div id="donate">

	  <h3><?php _e( 'How to support the software', THISISMYURL_WPTC_TEXTDOMAIN ); ?></h3>

	   <p><?php _e( 'Open source software such as this free WordPress plugin only work through the hard work of community members, volunteering their time or resources to make the software freely available. If you would like to show your support for this software, please consider donating towards the development effort.', THISISMYURL_WPTC_TEXTDOMAIN ); ?></p>
	   <p><?php _e( 'Here is how you can help:', THISISMYURL_WPTC_TEXTDOMAIN ); ?></p>

	   <ul>
		  <li><a href="https://wordpress.org/plugins/<?php echo THISISMYURL_WPTC_NAMESPACE; ?>/"><?php _e( 'Give it a great review on WordPress.org;', THISISMYURL_WPTC_TEXTDOMAIN ); ?></a></li>
		  <li><a href="https://wordpress.org/support/plugin/<?php echo THISISMYURL_WPTC_NAMESPACE; ?>"><?php _e( 'Offer free support in the plugin forums;', THISISMYURL_WPTC_TEXTDOMAIN ); ?></a></li>
		  <li><a href="https://github.com/thisismyurl/<?php echo THISISMYURL_WPTC_NAMESPACE; ?>/issues"><?php _e( 'Report an issue, or suggest feature request;', THISISMYURL_WPTC_TEXTDOMAIN ); ?></a></li>
		  <li><a href="http://codex.wordpress.org/I18n_for_WordPress_Developers"><?php _e( 'Translate the plugin into a local language;', THISISMYURL_WPTC_TEXTDOMAIN ); ?></a></li>
		  <li><a href="http://twitter.com/home?status=<?php printf( __( 'Thanks @thisismyurl for %s!', THISISMYURL_WPTC_TEXTDOMAIN ), THISISMYURL_WPTC_NAME );?>"><?php _e( 'Tell your friends about the plugin on Twitter;', THISISMYURL_WPTC_TEXTDOMAIN ); ?></a></li>
	   </ul>

	   <p><?php _e( 'Any support is greatly appreciated, and I hope you enjoy using this free plugin for WordPress.', THISISMYURL_WPTC_TEXTDOMAIN ); ?></p>

	   <form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="paypal_form">
	  <p><select name="amount">
	   	<option value="5"><?php _e( 'Donate $5', THISISMYURL_WPTC_TEXTDOMAIN );?></option>
		  <option value="10" selected><?php _e( 'Donate $10', THISISMYURL_WPTC_TEXTDOMAIN );?></option>
		  <option value="20"><?php _e( 'Donate $20', THISISMYURL_WPTC_TEXTDOMAIN );?></option>
	   </select>&nbsp;<input type="submit" value="Donate" class="button" /></p>


	   <input name="cmd" type="hidden" value="_donations" />
	   <input name="business" type="hidden" value="info@thisismyurl.com" />
	   <input name="item_name" type="hidden" value="<?php echo THISISMYURL_WPTC_NAME; ?>" />

	   <input name="currency_code" type="hidden" value="USD" />
	   </form>


	   <p>&#8212;&nbsp;<a href="http://thisismyurl.com/"><?php _e( 'Christopher Ross', THISISMYURL_WPTC_TEXTDOMAIN ); ?></a>&nbsp;(<a href="http://twitter.com/thisismyurl"><?php _e( '@thisismyurl', THISISMYURL_WPTC_TEXTDOMAIN ); ?></a>)</p>


	</div>

    <div class="clear"></div>


    	<?php

	}
	
	/**
	  * admin_init
	  *
	  * @access public
	  * @static
	  * @uses http://codex.wordpress.org/Function_Reference/add_settings_section
	  * @uses http://codex.wordpress.org/Function_Reference/add_settings_field
	  * @uses http://codex.wordpress.org/Function_Reference/register_setting
	  * @uses http://codex.wordpress.org/Function_Reference/register_uninstall_hook
	  * @since Method available since Release 15.01
	  *
	  */
	function admin_init() {

		add_settings_section(	'thisismyurl_wp_title_case_general',
								__( 'General settings', THISISMYURL_WPTC_TEXTDOMAIN ),
								FALSE,
								'thisismyurl_wp_title_case'
							);

		add_settings_field( 'thisismyurl_wp_title_case_min_word_length',
							__( 'Minimum Word Length', THISISMYURL_WPTC_TEXTDOMAIN ),
							array( $this, 'thisismyurl_wp_title_case_general_min_word' ),
							'thisismyurl_wp_title_case',
							'thisismyurl_wp_title_case_general'
						);

		add_settings_field( 'thisismyurl_wp_title_case_ignore_words',
							__( 'Ignored Words', THISISMYURL_WPTC_TEXTDOMAIN ),
							array( $this, 'thisismyurl_wp_title_case_general_ignore_words' ),
							'thisismyurl_wp_title_case',
							'thisismyurl_wp_title_case_general'
						);


		register_setting( 'thisismyurl_wp_title_case', 'thisismyurl_wp_title_case_min_word_length' );
		register_setting( 'thisismyurl_wp_title_case', 'thisismyurl_wp_title_case_ignore_words' );


		register_uninstall_hook( 'uninstall.php', FALSE );


		/* upgrade old plugin settings to new settings and delete them */

		$old_options = get_option( 'thisismyurl_title_case' );

		if ( ! empty( $old_options ) ) {

			if ( isset( $old_options['text_too_short_to_process'] ) && ! empty( $old_options['text_too_short_to_process'] ) )
				update_option( 'thisismyurl_wp_title_case_min_word_length', $old_options['text_too_short_to_process'] );

			if ( isset( $old_options['ignore_words'] ) && ! empty( $old_options['ignore_words'] ) )
				update_option( 'thisismyurl_wp_title_case_ignore_words', $old_options['ignore_words'] );

			delete_option( 'thisismyurl_title_case' );
		}

	}



	/**
	  * sets the minimum word length to process
	  *
	  * @access public
	  * @static
	  * @uses http://codex.wordpress.org/Function_Reference/get_option
	  * @uses http://codex.wordpress.org/Function_Reference/selected
	  * @since Method available since Release 15.01
	  *
	  */
	function thisismyurl_wp_title_case_general_min_word() {
		?>
		<select name="thisismyurl_wp_title_case_min_word_length" id="thisismyurl_wp_title_case_min_word_length">
			<?php
			$min_word_length = get_option( 'thisismyurl_wp_title_case_min_word_length' );

			if ( empty( $min_word_length ) )
				$min_word_length = 2;

			for ( $word_length = 1; $word_length < 8; $word_length++ ) { ?>
			<option value="<?php echo $word_length;?>" <?php echo selected( $min_word_length, $word_length );?>><?php echo $word_length;?></option>
			<?php } ?>
		</select>
		<?php
	}




	/**
	  * sets the ignored words for the plugin 
	  *
	  * @access public
	  * @static
	  * @uses http://codex.wordpress.org/Function_Reference/get_option
	  * @since Method available since Release 15.01
	  *
	  */
	function thisismyurl_wp_title_case_general_ignore_words() {

		$ignore_words = get_option( 'thisismyurl_wp_title_case_ignore_words' );
		?>
		<textarea id="thisismyurl_wp_title_case_ignore_words" name="thisismyurl_wp_title_case_ignore_words" rows="5" cols="50"><?php echo esc_textarea( $ignore_words );?></textarea>
		<?php
	}

}