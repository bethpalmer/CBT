<?php ?>
<div style="margin-top: 10px">
<table style="float:right; ">
<tr>
<td style="float:right;">
	<a class="xyz_smap_link"  target="_blank" href="http://kb.xyzscripts.com/wordpress-plugins/social-media-auto-publish/" style="margin-right:12px;">FAQ</a> 
</td>
<td style="float:right;">
	<a class="xyz_smap_link"  target="_blank" href="http://docs.xyzscripts.com/wordpress-plugins/social-media-auto-publish/">Readme</a> | 
</td>
<td style="float:right;">
	<a class="xyz_smap_link"  target="_blank" href="http://xyzscripts.com/wordpress-plugins/social-media-auto-publish/details">About</a> | 
</td>
<td style="float:right;">
	<a class="xyz_smap_link"  target="_blank" href="http://xyzscripts.com">XYZScripts</a> |
</td>

</tr>
</table>
</div>


<div style="clear: both"></div>