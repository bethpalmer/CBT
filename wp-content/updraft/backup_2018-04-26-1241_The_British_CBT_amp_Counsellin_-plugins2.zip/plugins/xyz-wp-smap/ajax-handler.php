<?php
require_once( dirname( __FILE__ ) . '/admin/ajax-reoder-element.php' );
require_once( dirname( __FILE__ ) . '/admin/ajax-addon-latest-info.php' );
?>